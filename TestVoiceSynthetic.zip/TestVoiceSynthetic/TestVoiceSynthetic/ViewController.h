//
//  ViewController.h
//  TestVoiceSynthetic
//
//  Created by ajiao on 2015-02-27.
//  Copyright (c) 2015年 tdwl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

