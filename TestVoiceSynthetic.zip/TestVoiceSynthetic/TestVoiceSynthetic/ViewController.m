//
//  ViewController.m
//  TestVoiceSynthetic
//
//  Created by ajiao on 2015-02-27.
//  Copyright (c) 2015年 tdwl. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController () <AVAudioPlayerDelegate>
{
    NSUInteger currentTrackNumber;
}

@property (nonatomic,strong)AVAudioPlayer *player1;
@property (nonatomic,strong)AVAudioPlayer* audioPlayer;
@property (nonatomic,strong)NSArray *arrayOfTracks; // 这个数组中保存音频的名称

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//运行不了
//    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"Button_Click_Sound" ofType:@"mp3"];
//    NSURL *urlPath = [NSURL URLWithString:filePath];
////    NSData *data = [[NSData alloc]initWithContentsOfURL:urlPath];
//    NSData *data = [[NSData alloc]initWithContentsOfFile:filePath];
//    AVAudioPlayer* player = [[AVAudioPlayer alloc] initWithData:data error:nil];
////    AVAudioPlayer* player = [[AVAudioPlayer alloc]initWithContentsOfURL:urlPath error:nil];
//    player.volume = 0.5;
//    [player prepareToPlay];
//    player.numberOfLoops = -1;
//    [player play];
    
    
//    //可以播放
//    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"1" ofType:@"wav"];
////     NSString *filePath = [[NSBundle mainBundle]pathForResource:@"Button_Click_Sound" ofType:@"mp3"];
//    NSURL *urlPath = [NSURL fileURLWithPath:filePath];
//    NSData *data = [[NSData alloc]initWithContentsOfURL:urlPath];
//     self.player1 = [[AVAudioPlayer alloc] initWithData:data error:nil];
////    self.player1 = [[AVAudioPlayer alloc] initWithContentsOfURL:urlPath error:nil];
//    self.player1 .volume = 0.5;
//    [self.player1  prepareToPlay];
//    self.player1 .numberOfLoops = -1;
//    [self.player1  play];
    
//    //可以播放
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"3" ofType:@"wav"];
    NSString *filePath1 = [[NSBundle mainBundle]pathForResource:@"2" ofType:@"wav"];
        NSString *filePath2 = [[NSBundle mainBundle]pathForResource:@"邓丽君" ofType:@"wav"];
//    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"Button_Click_Sound" ofType:@"mp3"];
//    NSString *filePath1 = [[NSBundle mainBundle]pathForResource:@"Coin_DiaoLuo" ofType:@"mp3"];
    NSURL *urlPath = [NSURL fileURLWithPath:filePath];
    NSURL *urlPath1 = [NSURL fileURLWithPath:filePath1];
     NSURL *urlPath2 = [NSURL fileURLWithPath:filePath2];
    NSMutableData *data = [[NSMutableData alloc]initWithContentsOfURL:urlPath];
    NSMutableData *data1 = [[NSMutableData alloc]initWithContentsOfURL:urlPath1];
    NSData *data2 = [[NSData alloc]initWithContentsOfURL:urlPath2];
    [data appendData:data1];
    [data appendData:data2];
//    self.player1 = [[AVAudioPlayer alloc] initWithData:data error:nil];
     self.player1 = [[AVAudioPlayer alloc] initWithData:data error:nil];
    self.player1 .volume = 0.5;
    [self.player1  prepareToPlay];
    self.player1 .numberOfLoops = -1;
    [self.player1  play];
//
    
//    self.arrayOfTracks = @[@"1",@"2",@"3",@"4",@"5",@"6"];
//    [self startPlaying];
    
    
}

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    if (flag) {
        if (currentTrackNumber < [_arrayOfTracks count] - 1) {
            currentTrackNumber ++;
            if (_audioPlayer) {
                [_audioPlayer stop];
                _audioPlayer = nil;
            }
            _audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:[[NSString alloc] initWithString:[_arrayOfTracks objectAtIndex:currentTrackNumber]] ofType:@"wav"]] error:NULL];
            _audioPlayer.delegate = self;
            [_audioPlayer play];
        }
    }
}
- (void)startPlaying
{
    if (_audioPlayer) {
        [_audioPlayer stop];
        _audioPlayer = nil;
    } else {
        _audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:[[NSString alloc] initWithString:[_arrayOfTracks objectAtIndex:currentTrackNumber]] ofType:@"wav"]] error:NULL];
        _audioPlayer.delegate = self;
        [_audioPlayer play];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
